package pe.edu.upeu.examenunidad1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenUnidad1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
